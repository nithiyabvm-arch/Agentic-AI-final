# Quickstart: STM32 GenAI Analyzer Phase 1

## Prerequisites

- Python 3.11 or newer.
- A local STM32 Embedded C project for validation.
- A guideline JSON file matching [guidelines.schema.json](./contracts/guidelines.schema.json).
- An OpenAI API key for live analysis and remediation runs.

## Setup

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -U pip
python -m pip install -e ".[dev]"
```

## Validate Contracts

```powershell
pytest tests\contract
```

Expected result:

- Guideline fixtures validate against the guideline schema.
- Generated or fixture `context.json` files validate against the context schema.
- Generated or fixture `final_analysis_report.json` files validate against the final analysis schema.
- Remediation manifests validate against the remediation schema.

## Run Unit Tests

```powershell
pytest tests\unit
```

Expected result:

- Source discovery identifies STM32 application files.
- C parsing extracts function spans.
- Dependency and call graphs are built from fixture projects.
- Guideline validation rejects malformed input.
- Project writer never modifies the original fixture project.

## Run Integration Tests

```powershell
pytest tests\integration
```

Expected result:

- Context generation produces a valid `context.json` for the sample project.
- Analysis uses a fake AI client and produces a valid `final_analysis_report.json`.
- Remediation creates a separate remediated project and valid manifest.
- GUI workflow state transitions enforce prerequisites.

## Run the GUI

```powershell
streamlit run stm32_genai_analyzer\app.py
```

Expected workflow:

1. Enter an API key and select a model.
2. Select a local STM32 project path.
3. Upload guideline JSON.
4. Generate context and verify `context.json` is created.
5. Run analysis and verify `final_analysis_report.json` is created.
6. Run remediation and verify `remediated_project` is created.

## Manual Validation Checks

- Original project files are unchanged after remediation.
- `context.json` includes source files, dependency graph, call graph, symbols, interfaces, peripherals, and diagnostics.
- `final_analysis_report.json` includes affected locations, guideline IDs, explanations, skipped items, and summary counts.
- Remediation output reports each issue as remediated, skipped, unresolved, or failed.
- Compiler, retry compilation, review node, and PDF report generation are not exposed in Phase 1.
