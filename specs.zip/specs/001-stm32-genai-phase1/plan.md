# Implementation Plan: STM32 GenAI Analyzer Phase 1

**Branch**: `001-stm32-genai-phase1` | **Date**: 2026-06-18 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `specs/001-stm32-genai-phase1/spec.md`

## Summary

Deliver Phase 1 of STM32 GenAI Analyzer as a local Python application with a Streamlit GUI and reusable workflow modules for context generation, coding-guideline analysis, and remediation output. The system will scan STM32 Embedded C projects, export `context.json`, analyze functions against uploaded structured guidelines with OpenAI-assisted structured responses, export `final_analysis_report.json`, and create a separate `remediated_project` without modifying the original source.

The implementation will favor deterministic parsing and validation before AI calls: file discovery, include/dependency extraction, function boundary detection, symbol ownership, call relationships, interface contracts, and peripheral ownership are built locally. AI calls are reserved for guideline interpretation, violation explanation, and remediation suggestions using schema-constrained JSON outputs so generated reports remain machine-checkable.

## Technical Context

**Language/Version**: Python 3.11+

**Primary Dependencies**: Streamlit for GUI, OpenAI Python SDK for model calls, Pydantic for data validation, NetworkX for graph construction/serialization support, tree-sitter with C grammar for robust C parsing, pytest for tests

**Storage**: Local filesystem only; JSON artifacts for `context.json`, `final_analysis_report.json`, remediation manifests, and temporary run state

**Testing**: pytest unit tests for parsers and models, integration tests with sample STM32 projects, contract tests validating JSON artifacts against schemas, GUI smoke tests for workflow state transitions

**Target Platform**: Local desktop/workstation environment on Windows first, with path handling compatible with Linux/macOS where practical

**Project Type**: Local Streamlit application plus internal Python package

**Performance Goals**: Generate context for representative projects with at least 20 application source files in under 5 minutes; identify at least 95% of expected application source files; capture at least 90% of validation call relationships relevant to analyzed functions

**Constraints**: Original project must never be modified by remediation; malformed guidelines block analysis; missing or invalid AI credentials block AI-assisted steps; partial context generation may continue for unreadable non-critical files if skipped files are reported

**Scale/Scope**: Phase 1 supports local STM32 Embedded C projects, structured guideline JSON upload, function-level analysis/remediation, and three output classes: `context.json`, `final_analysis_report.json`, and `remediated_project`

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

The repository constitution currently contains placeholder principles only and defines no enforceable gates. The plan therefore applies the feature spec as the governing source for Phase 1 and uses the following project-level quality gates:

- Preserve source project integrity: remediation writes only to `remediated_project`.
- Keep Phase 1 bounded: compiler, retry compilation, review node, and PDF reporting are excluded.
- Validate all externalized data: guideline input, context output, analysis output, and remediation status are schema-checked.
- Keep workflows independently testable: context builder, analysis node, remediation node, and GUI orchestration can each be validated in isolation.

Gate status before research: PASS.

## Project Structure

### Documentation (this feature)

```text
specs/001-stm32-genai-phase1/
|-- plan.md
|-- research.md
|-- data-model.md
|-- quickstart.md
|-- contracts/
|   |-- context.schema.json
|   |-- final-analysis-report.schema.json
|   |-- guidelines.schema.json
|   |-- remediation-manifest.schema.json
|   `-- gui-workflow.md
|-- checklists/
|   `-- requirements.md
`-- tasks.md
```

### Source Code (repository root)

```text
stm32_genai_analyzer/
|-- __init__.py
|-- app.py
|-- config.py
|-- models/
|   |-- __init__.py
|   |-- analysis.py
|   |-- context.py
|   |-- guidelines.py
|   `-- remediation.py
|-- context_builder/
|   |-- __init__.py
|   |-- discovery.py
|   |-- parser.py
|   |-- dependencies.py
|   |-- call_graph.py
|   |-- symbols.py
|   |-- interfaces.py
|   |-- peripherals.py
|   `-- exporter.py
|-- analysis/
|   |-- __init__.py
|   |-- guideline_loader.py
|   |-- prompt_builder.py
|   |-- openai_client.py
|   |-- analyzer.py
|   `-- reporter.py
|-- remediation/
|   |-- __init__.py
|   |-- issue_reader.py
|   |-- function_extractor.py
|   |-- prompt_builder.py
|   |-- remediator.py
|   |-- project_writer.py
|   `-- manifest.py
|-- gui/
|   |-- __init__.py
|   |-- state.py
|   |-- pages.py
|   `-- components.py
`-- utils/
    |-- __init__.py
    |-- paths.py
    |-- json_io.py
    `-- logging.py

tests/
|-- fixtures/
|   |-- sample_stm32_project/
|   `-- guidelines/
|-- contract/
|   |-- test_context_schema.py
|   |-- test_analysis_report_schema.py
|   |-- test_guidelines_schema.py
|   `-- test_remediation_manifest_schema.py
|-- integration/
|   |-- test_context_to_analysis.py
|   |-- test_analysis_to_remediation.py
|   `-- test_gui_workflow_state.py
`-- unit/
    |-- test_discovery.py
    |-- test_c_parser.py
    |-- test_graph_builders.py
    |-- test_guideline_loader.py
    |-- test_prompt_builders.py
    |-- test_function_extractor.py
    `-- test_project_writer.py
```

**Structure Decision**: Use a single Python package with clear internal module boundaries. This keeps the GUI, context builder, analysis, and remediation nodes in one deployable local application while still allowing each workflow node to be unit-tested and later reused by CLI or future pipeline nodes.

## Phase 0: Research

Research output is captured in [research.md](./research.md). Key decisions:

- Use Python 3.11+ and Streamlit to match the requested GUI workflow and keep local execution simple.
- Use tree-sitter C parsing before regex fallbacks for function extraction and call discovery.
- Use Pydantic models as the canonical artifact contracts and emit JSON validated against schemas.
- Use OpenAI structured outputs for analysis and remediation responses to reduce invalid report/remediation shapes.
- Use separate project-copy writing for remediation to enforce original source preservation.

## Phase 1: Design & Contracts

Design artifacts:

- [data-model.md](./data-model.md): Entities, relationships, validation rules, and workflow state transitions.
- [contracts/context.schema.json](./contracts/context.schema.json): Contract for `context.json`.
- [contracts/guidelines.schema.json](./contracts/guidelines.schema.json): Contract for uploaded coding guidelines.
- [contracts/final-analysis-report.schema.json](./contracts/final-analysis-report.schema.json): Contract for `final_analysis_report.json`.
- [contracts/remediation-manifest.schema.json](./contracts/remediation-manifest.schema.json): Contract for remediation status output.
- [contracts/gui-workflow.md](./contracts/gui-workflow.md): User-facing GUI workflow contract.
- [quickstart.md](./quickstart.md): End-to-end validation guide.

Post-design Constitution Check: PASS. The design preserves original projects, validates input/output artifacts, keeps future-phase items out of scope, and supports independent testing of all primary workflows.

## Implementation Details

### Context Builder

1. Accept a local STM32 project path and normalize paths relative to the project root.
2. Discover application files by extension and common STM32 folder conventions while excluding generated/build output directories.
3. Parse C headers and source files into file summaries with includes, macros, functions, symbols, comments relevant to interfaces, and peripheral references.
4. Build a dependency graph from include relationships and known project file mappings.
5. Build a call graph by mapping function definitions and references across parsed function bodies.
6. Determine symbol ownership by definition location and exported declarations.
7. Infer interface contracts from header/source boundaries, shared declarations, and cross-module calls.
8. Infer peripheral ownership from HAL/LL peripheral handles, initialization functions, interrupt handlers, and module-level usage.
9. Export `context.json` with skipped-file diagnostics and validation status.

### Analysis Node

1. Load and validate structured guideline JSON.
2. Load and validate `context.json`.
3. Partition analysis by function with enough local context to evaluate guideline compliance.
4. Build deterministic prompts containing guideline references, affected function context, and requested output schema.
5. Call the configured AI model through a small adapter that supports retries, timeout handling, and schema validation.
6. Merge per-function findings into a consolidated issue list.
7. Emit `final_analysis_report.json` with run metadata, analyzed functions, issues, skipped items, and validation summary.

### Remediation Node

1. Load `final_analysis_report.json` and validate it against the report contract.
2. Resolve each issue to a unique source file and function span.
3. Extract affected function bodies from the original project.
4. Build remediation prompts with the guideline violation, relevant context, and exact function body.
5. Validate returned remediation suggestions before applying them to the project copy.
6. Copy the original project into `remediated_project` before modifying any files.
7. Replace only uniquely resolved affected function bodies.
8. Emit a remediation manifest containing remediated, skipped, unresolved, and failed items.

### Streamlit GUI

1. Provide session inputs for API key, model selection, project path, and guideline upload.
2. Gate each action based on prerequisite completion: guidelines and project before context, context before analysis, analysis before remediation.
3. Show progress, completion, artifact locations, and actionable errors for each node.
4. Keep credentials in session state only and avoid writing them to artifacts.
5. Expose downloadable or visible paths for `context.json`, `final_analysis_report.json`, and `remediated_project`.

## Validation Strategy

- Unit tests cover path normalization, source discovery, parsing, graph building, guideline validation, prompt assembly, function extraction, and project-copy writes.
- Contract tests validate all emitted and accepted JSON artifacts against the schemas under `contracts/`.
- Integration tests run context generation on sample STM32 projects and verify discovery, graph, symbol, interface, and peripheral expectations.
- Analysis tests use a fake AI client to validate prompt construction, issue merging, schema rejection, and report generation without external calls.
- Remediation tests use seeded analysis reports to verify affected function extraction, safe project-copy writes, skipped unresolved items, and original project preservation.
- GUI tests validate state transitions and error handling with mocked workflow services.

## Complexity Tracking

No constitution violations or complexity exceptions are required.
