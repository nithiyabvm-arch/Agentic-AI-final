# Data Model: STM32 GenAI Analyzer Phase 1

## Entity Relationships

```text
STM32Project
|-- SourceFile[]
|   |-- Function[]
|   |-- Symbol[]
|   |-- Include[]
|   `-- PeripheralReference[]
|-- DependencyGraph
|-- CallGraph
|-- InterfaceContract[]
`-- PeripheralOwnership[]

GuidelineSet
`-- Guideline[]

AnalysisRun
|-- AnalyzedFunction[]
|-- AnalysisIssue[]
`-- SkippedItem[]

RemediationRun
|-- RemediationTask[]
|-- RemediationResult[]
`-- RemediatedProject
```

## Entities

### STM32Project

Represents a selected local STM32 Embedded C project.

**Fields**:

- `project_id`: Stable identifier for the analyzed project path and run.
- `root_path`: Local root path selected by the user.
- `discovered_at`: Timestamp for context generation.
- `source_files`: List of discovered source files.
- `skipped_files`: Files excluded or unreadable with reason.
- `context_status`: `complete`, `partial`, or `failed`.

**Validation rules**:

- `root_path` must exist and be readable.
- At least one source file is required for successful context generation.
- Skipped files must include a reason.

### SourceFile

Represents an application source or header file discovered in the project.

**Fields**:

- `file_id`: Stable project-relative file identifier.
- `relative_path`: Path relative to the STM32 project root.
- `language`: `c`, `header`, or `other_supported`.
- `read_status`: `read`, `skipped`, or `error`.
- `includes`: Included files or headers.
- `functions`: Functions defined in the file.
- `symbols`: Symbols defined or declared in the file.
- `peripheral_references`: Peripheral references detected in the file.

**Validation rules**:

- `relative_path` must be project-relative.
- Files with `read_status = error` must include an error reason.

### Function

Represents a callable code unit.

**Fields**:

- `function_id`: Stable identifier derived from file path, function name, and location.
- `name`: Function name.
- `file_id`: Owning source file.
- `signature`: Function signature text.
- `start_line`: Start line in source file.
- `end_line`: End line in source file.
- `calls`: Referenced function names or resolved function IDs.
- `symbols_used`: Referenced symbols.
- `peripherals_used`: Referenced peripherals.

**Validation rules**:

- `start_line` must be less than or equal to `end_line`.
- A function targeted for remediation must have a resolvable unique file and line span.

### DependencyGraph

Represents file and component dependency relationships.

**Fields**:

- `nodes`: Source files or logical components.
- `edges`: Directed dependency relationships.
- `unresolved_includes`: Include references that could not be mapped to a discovered file.

**Validation rules**:

- Edges must reference existing graph nodes unless explicitly marked unresolved.

### CallGraph

Represents function-level call relationships.

**Fields**:

- `nodes`: Function IDs.
- `edges`: Directed caller-to-callee relationships.
- `unresolved_calls`: Call names that could not be mapped uniquely.

**Validation rules**:

- Resolved edges must reference known function IDs.
- Unresolved calls must include caller context.

### SymbolOwnership

Represents ownership of functions, variables, macros, typedefs, or project-level symbols.

**Fields**:

- `symbol_name`: Symbol name.
- `symbol_type`: `function`, `variable`, `macro`, `typedef`, `struct`, `enum`, or `unknown`.
- `owner_file_id`: Source file that defines or owns the symbol.
- `declaration_locations`: Locations where the symbol is declared.
- `definition_location`: Location where the symbol is defined.
- `confidence`: `high`, `medium`, or `low`.

**Validation rules**:

- High-confidence ownership requires a definition location.
- Low-confidence ownership must include a reason.

### InterfaceContract

Represents an inferred boundary between source components.

**Fields**:

- `contract_id`: Stable identifier.
- `provider_file_id`: File or component providing the interface.
- `consumer_file_ids`: Files or components consuming the interface.
- `symbols`: Symbols participating in the contract.
- `contract_type`: `header_api`, `callback`, `interrupt`, `shared_state`, or `unknown`.
- `evidence`: Source locations supporting the inference.

**Validation rules**:

- Contracts must include at least one provider and one piece of evidence.

### PeripheralOwnership

Represents inferred ownership of STM32 peripherals.

**Fields**:

- `peripheral_id`: Peripheral or handle name.
- `owner_file_id`: File or component responsible for the peripheral.
- `init_functions`: Initialization functions associated with the peripheral.
- `usage_locations`: Source locations using the peripheral.
- `confidence`: `high`, `medium`, or `low`.

**Validation rules**:

- Low-confidence ownership must include evidence and reason.

### GuidelineSet

Represents uploaded coding guidelines.

**Fields**:

- `guideline_set_id`: Identifier for the uploaded guideline set.
- `title`: Human-readable title.
- `version`: Optional guideline version.
- `guidelines`: List of rules.

**Validation rules**:

- Must contain at least one guideline.
- Each guideline must have an ID and checkable description.

### Guideline

Represents one coding rule.

**Fields**:

- `guideline_id`: Stable rule identifier.
- `title`: Short title.
- `description`: Rule text.
- `severity`: `info`, `minor`, `major`, `critical`.
- `category`: Optional category such as safety, readability, portability, or reliability.
- `examples`: Optional compliant/non-compliant examples.

**Validation rules**:

- `guideline_id`, `title`, and `description` are required.
- Severity defaults to `major` when absent.

### AnalysisRun

Represents one analysis execution.

**Fields**:

- `analysis_id`: Run identifier.
- `project_id`: Project context being analyzed.
- `guideline_set_id`: Guideline set used for analysis.
- `model`: User-selected model name.
- `started_at`: Start timestamp.
- `completed_at`: Completion timestamp.
- `status`: `complete`, `partial`, or `failed`.
- `analyzed_functions`: Functions considered.
- `issues`: Guideline violations.
- `skipped_items`: Functions or files skipped with reasons.

**Validation rules**:

- Analysis requires valid project context and guideline set.
- Failed or partial analysis must include diagnostic messages.

### AnalysisIssue

Represents one detected guideline violation.

**Fields**:

- `issue_id`: Stable issue identifier.
- `guideline_id`: Violated guideline.
- `severity`: Effective issue severity.
- `function_id`: Affected function when applicable.
- `location`: File and line span.
- `summary`: Short issue summary.
- `explanation`: Human-readable explanation.
- `evidence`: Relevant source excerpt or description.
- `remediation_eligible`: Whether remediation can target this issue.

**Validation rules**:

- Must include either a function ID or a precise source location.
- Must include guideline reference and explanation.

### RemediationTask

Represents one issue selected for remediation.

**Fields**:

- `task_id`: Stable remediation task identifier.
- `issue_id`: Source analysis issue.
- `function_id`: Target function.
- `original_function_body`: Extracted original function body.
- `status`: `pending`, `remediated`, `skipped`, `unresolved`, or `failed`.

**Validation rules**:

- Tasks can only be created from remediation-eligible issues.
- Tasks requiring source replacement must resolve to a unique function span.

### RemediationResult

Represents the outcome of one remediation task.

**Fields**:

- `task_id`: Remediation task.
- `issue_id`: Source issue.
- `status`: `remediated`, `skipped`, `unresolved`, or `failed`.
- `target_file`: File updated in `remediated_project`.
- `changed_line_span`: Replaced line span when applicable.
- `message`: Human-readable result or failure reason.

**Validation rules**:

- Remediated results must include target file and changed line span.
- Skipped, unresolved, and failed results must include a reason.

### RemediatedProject

Represents the generated project copy.

**Fields**:

- `source_project_root`: Original project root.
- `output_root`: Remediated project path.
- `created_at`: Timestamp.
- `results`: Remediation results.
- `original_preserved`: Boolean verification flag.

**Validation rules**:

- `output_root` must not be the same path as `source_project_root`.
- `original_preserved` must be true for a successful remediation run.

## State Transitions

### Workflow Run

```text
idle
-> project_selected
-> guidelines_loaded
-> context_generated
-> analysis_completed
-> remediation_completed
```

Error states can occur at each active step:

- `context_failed`
- `analysis_blocked`
- `analysis_failed`
- `remediation_blocked`
- `remediation_failed`

Blocked states are recoverable when the user fixes missing or invalid inputs.
