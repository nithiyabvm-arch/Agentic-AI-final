# Research: STM32 GenAI Analyzer Phase 1

## Decision: Implement as a Python 3.11+ local application

**Rationale**: The required Phase 1 modules are file-heavy local workflows: scanning STM32 projects, parsing C source, writing JSON artifacts, and presenting a Streamlit GUI. Python provides mature libraries for parsing, graphing, validation, testing, JSON handling, and Streamlit application delivery.

**Alternatives considered**:

- Node.js: workable for GUI and JSON workflows, weaker fit for local C parsing and scientific/graph tooling.
- Desktop-native application stack: unnecessary for Phase 1 and increases packaging complexity.
- Web service plus frontend: heavier than needed because Phase 1 is local-project analysis, not multi-user hosting.

## Decision: Use Streamlit for the Phase 1 GUI

**Rationale**: The requirements explicitly include a Streamlit GUI. Streamlit supports rapid local workflows with form inputs, file uploads, progress indicators, and artifact paths without requiring a separate frontend/backend split.

**Alternatives considered**:

- CLI only: does not satisfy the GUI requirement.
- Custom web frontend: adds a second application surface without Phase 1 value.
- Desktop GUI toolkit: more packaging work and less aligned with the requested completed module.

## Decision: Use tree-sitter C parsing for source structure

**Rationale**: Function extraction, call graph construction, symbol ownership, and safe remediation need reliable function boundaries. A syntax parser is more robust than regex for Embedded C projects with macros, comments, nested blocks, and mixed declarations.

**Alternatives considered**:

- Regex-only parsing: simple but too fragile for safe function replacement and call graph generation.
- Full compiler frontend: more accurate but introduces toolchain and include-path complexity outside Phase 1.
- ctags only: useful for symbol indexing but insufficient for function body extraction and call relationships.

## Decision: Use Pydantic models and JSON schemas for artifacts

**Rationale**: The system exchanges structured artifacts between workflow nodes. Pydantic models provide a single source of truth for validation, serialization, and tests, while JSON schemas let fixtures and generated artifacts be contract-tested independently.

**Alternatives considered**:

- Unvalidated dictionaries: faster initially but makes downstream failures harder to diagnose.
- Database storage: unnecessary because outputs are file-based and local.
- Dataclasses only: useful internally but weaker for runtime validation and schema generation.

## Decision: Use NetworkX for dependency and call graph assembly

**Rationale**: Dependency and call graphs require node/edge construction, attributes, traversal, and serialization. NetworkX is sufficient for Phase 1 project scale and avoids custom graph code.

**Alternatives considered**:

- Custom graph structures: lower dependency count but increases implementation and testing burden.
- Graph database: unnecessary for local single-project analysis.

## Decision: Use OpenAI structured outputs for AI-assisted analysis and remediation

**Rationale**: The analysis report and remediation tasks must be machine-checkable JSON. Structured AI responses reduce invalid output risk by requiring generated findings and remediations to match expected schemas before they are merged into artifacts.

**Alternatives considered**:

- Free-form text responses: harder to validate and reconcile with `final_analysis_report.json`.
- JSON-only prompting without schema validation: better than free text but still less reliable.
- Fully deterministic static rules: useful for future checks, but Phase 1 requirements explicitly call for GPT-assisted analysis and remediation.

## Decision: Use fake AI clients in automated tests

**Rationale**: Unit and integration tests should be deterministic, inexpensive, and runnable without live credentials. The production OpenAI adapter remains small and separately covered by contract tests around request/response handling.

**Alternatives considered**:

- Live API tests in normal test runs: slow, costly, and dependent on network/API availability.
- No AI boundary tests: leaves core behavior unverified.

## Decision: Remediation writes to a copied project only

**Rationale**: The feature spec requires the original STM32 project to remain unchanged. Copy-first remediation provides a clear safety boundary and allows users to diff original and remediated code.

**Alternatives considered**:

- In-place modification with backups: higher risk and harder to reason about.
- Patch files only: safe, but does not satisfy the requested `remediated_project` output.

## Decision: Defer compiler, retry, review, and PDF workflows

**Rationale**: The feature specification explicitly identifies these as future-phase modules. Including them in Phase 1 would expand scope beyond the requested outputs and obscure validation of context, analysis, remediation, and GUI workflows.

**Alternatives considered**:

- Stub future modules now: creates maintenance surface without user-facing Phase 1 value.
- Partial compilation checks: risks implying correctness that Phase 1 is not scoped to prove.
