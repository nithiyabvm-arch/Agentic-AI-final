# GUI Workflow Contract: STM32 GenAI Analyzer Phase 1

## Purpose

Defines the expected user-visible workflow for the Streamlit GUI. This is a behavioral contract for implementation and testing, not a visual design specification.

## Required Inputs

- API key: Required before AI-assisted analysis or remediation.
- Model selection: Required before AI-assisted analysis or remediation.
- STM32 project path: Required before context generation.
- Guideline JSON upload: Required before analysis.

## Workflow States

| State | Required Inputs | Enabled Actions | Expected Output |
|-------|-----------------|-----------------|-----------------|
| `idle` | None | Enter API key, select model, choose project, upload guidelines | None |
| `project_ready` | Project path | Generate context | None |
| `guidelines_ready` | Guideline JSON | Generate context if project is ready | None |
| `context_ready` | Project path, valid `context.json` | Run analysis | `context.json` |
| `analysis_ready` | Valid `final_analysis_report.json` | Run remediation | `final_analysis_report.json` |
| `remediation_ready` | Valid remediation output | View output paths | `remediated_project`, remediation manifest |

## Action Contracts

### Generate Context

**Preconditions**:

- Project path is present.
- Project path is readable.

**Success result**:

- `context.json` is created.
- GUI shows success status and artifact path.

**Failure result**:

- GUI shows a clear error when no source files are found or project cannot be read.
- Analysis action remains disabled.

### Run Analysis

**Preconditions**:

- API key is present.
- Model is selected.
- Guideline JSON is valid.
- `context.json` exists and is valid.

**Success result**:

- `final_analysis_report.json` is created.
- GUI shows issue count, skipped count, and artifact path.

**Failure result**:

- GUI identifies the missing or invalid prerequisite.
- Remediation action remains disabled.

### Run Remediation

**Preconditions**:

- API key is present.
- Model is selected.
- `final_analysis_report.json` exists and is valid.
- At least one issue is remediation eligible.

**Success result**:

- `remediated_project` is created.
- Remediation manifest is created.
- GUI shows remediated, skipped, unresolved, and failed counts.

**Failure result**:

- GUI reports the failure reason.
- Original project remains unchanged.

## Error Message Requirements

- Missing project path: identify that the user must select a readable STM32 project.
- Missing guidelines: identify that a valid guideline JSON file is required.
- Invalid guidelines: identify the schema validation problem.
- Missing API key: identify that AI-assisted steps require a credential.
- Invalid context/report artifacts: identify the invalid artifact and block dependent actions.
- Remediation ambiguity: identify the affected issue/function and mark it unresolved.
