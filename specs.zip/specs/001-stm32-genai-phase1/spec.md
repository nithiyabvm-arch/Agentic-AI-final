# Feature Specification: STM32 GenAI Analyzer Phase 1

**Feature Branch**: `001-stm32-genai-phase1`

**Created**: 2026-06-18

**Status**: Draft

**Input**: User description: "Read high-lvl-reqs.txt. Generate a complete feature specification. Create: specs/001-stm32-genai-phase1/spec.md"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Build Project Understanding (Priority: P1)

As an embedded software engineer, I want the analyzer to inspect an STM32 project and produce a complete project context so that later compliance analysis can understand files, dependencies, symbols, interfaces, calls, and peripheral ownership.

**Why this priority**: Project context is the foundation for every later workflow. Without a reliable context, analysis and remediation cannot be trusted.

**Independent Test**: Can be fully tested by selecting a representative STM32 project, running context generation, and verifying that the exported context identifies source files, dependency relationships, call relationships, symbol ownership, interface contracts, and peripheral ownership.

**Acceptance Scenarios**:

1. **Given** a valid STM32 project with application source files, **When** the user generates project context, **Then** the system creates a project context export containing discovered source files and structural relationships.
2. **Given** source files with functions that call one another, **When** context generation completes, **Then** the generated context includes a call graph that allows downstream analysis to identify function relationships.
3. **Given** project code that uses STM32 peripherals through defined ownership patterns, **When** context generation completes, **Then** the generated context identifies the owning code areas for those peripherals.

---

### User Story 2 - Analyze Coding Guideline Compliance (Priority: P2)

As a compliance reviewer, I want to provide coding guidelines and run an AI-assisted analysis on STM32 functions so that I receive a structured list of guideline violations with enough detail to understand the affected code.

**Why this priority**: Compliance issue detection is the primary value of the analyzer once context exists.

**Independent Test**: Can be fully tested by providing a known guideline set and sample project with seeded violations, running analysis, and verifying that the final report lists the expected violations and affected functions.

**Acceptance Scenarios**:

1. **Given** a generated project context and uploaded coding guidelines, **When** the user starts analysis, **Then** the system evaluates STM32 functions against the guidelines and creates an issue report.
2. **Given** a function that violates one or more supplied guidelines, **When** analysis completes, **Then** the final report identifies the affected function, violated guideline, and issue explanation.
3. **Given** a function that complies with the supplied guidelines, **When** analysis completes, **Then** the final report does not report a violation for that function.

---

### User Story 3 - Generate Remediated Project Copy (Priority: P3)

As an embedded developer, I want the analyzer to generate suggested remediations in a separate project copy so that I can review corrected code without overwriting the original STM32 project.

**Why this priority**: Remediation turns analysis findings into actionable code changes while preserving the source project for auditability and comparison.

**Independent Test**: Can be fully tested by running remediation on an analysis report with known issues and verifying that only affected functions are changed in a remediated project copy while the original project remains unchanged.

**Acceptance Scenarios**:

1. **Given** a completed analysis report with issues, **When** the user starts remediation, **Then** the system extracts affected function bodies and generates remediation suggestions for those functions.
2. **Given** generated remediation suggestions, **When** remediation completes, **Then** the system writes the updated source files into a separate remediated project output.
3. **Given** an original STM32 project, **When** remediation completes, **Then** the original source files remain unchanged.

---

### User Story 4 - Operate Workflow Through a GUI (Priority: P4)

As a user who may not be comfortable with command-line workflows, I want a graphical interface to provide credentials, choose an analysis model, upload guidelines, generate context, run analysis, and run remediation from one place.

**Why this priority**: A guided interface makes Phase 1 usable by reviewers and developers who need a repeatable workflow rather than separate manual steps.

**Independent Test**: Can be fully tested by opening the GUI, completing each available action in sequence, and verifying that the expected output artifacts are produced.

**Acceptance Scenarios**:

1. **Given** the GUI is open, **When** the user provides a valid service credential and selects a model, **Then** the system stores the session inputs needed to run AI-assisted steps.
2. **Given** the user uploads a guideline file, **When** the user starts analysis after context generation, **Then** the system uses those guidelines for the compliance analysis.
3. **Given** context generation and analysis have completed, **When** the user starts remediation, **Then** the system creates the remediated project output and makes completion status visible to the user.

### Edge Cases

- If the selected project contains no discoverable STM32 application source files, the system must report that no analyzable project files were found and must not produce misleading analysis results.
- If the guideline file is missing, empty, or malformed, analysis must stop with a clear message explaining that valid guidelines are required.
- If the AI service credential is missing or invalid, AI-assisted analysis or remediation must not start and the user must receive a clear recovery message.
- If a source file cannot be read, the context export must identify the skipped file and analysis must continue only for readable content.
- If the analysis report references a function that can no longer be found in the project, remediation must skip that item and report it as unresolved.
- If multiple functions or symbols share the same name in different files or scopes, reports and remediation must identify the affected location clearly enough to avoid ambiguity.
- If remediation cannot produce a safe replacement for an affected function, the item must be reported as not remediated rather than applying an uncertain change.
- Future-phase capabilities are out of scope for Phase 1: compilation, retry compilation, formal review workflow, and PDF report generation.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST allow a user to select or provide an STM32 project for analysis.
- **FR-002**: System MUST discover STM32 application source files within the selected project.
- **FR-003**: System MUST build a dependency graph that represents relationships among discovered project files.
- **FR-004**: System MUST build a call graph that represents function-level call relationships relevant to analysis.
- **FR-005**: System MUST identify symbol ownership for discovered functions, variables, and project-level symbols where ownership can be determined.
- **FR-006**: System MUST identify interface contracts used between project components.
- **FR-007**: System MUST identify peripheral ownership within the STM32 project where ownership can be inferred from the source.
- **FR-008**: System MUST generate a project context artifact named `context.json`.
- **FR-009**: System MUST allow a user to provide coding guidelines for compliance analysis.
- **FR-010**: System MUST validate that provided coding guidelines are readable and structurally usable before analysis starts.
- **FR-011**: System MUST allow a user to provide the credential required for AI-assisted analysis and remediation.
- **FR-012**: System MUST allow a user to select the AI model used for AI-assisted steps.
- **FR-013**: System MUST analyze STM32 functions against the provided coding guidelines using the generated project context.
- **FR-014**: System MUST detect and report coding guideline violations found during analysis.
- **FR-015**: System MUST generate an issue report that includes, for each reported issue, the affected function or code location, the relevant guideline, and an explanation of the violation.
- **FR-016**: System MUST generate a final analysis artifact named `final_analysis_report.json`.
- **FR-017**: System MUST read the final analysis report as the source of remediation tasks.
- **FR-018**: System MUST extract affected function bodies before requesting remediation suggestions.
- **FR-019**: System MUST generate remediation prompts or requests that include the issue context needed to produce a corrected function.
- **FR-020**: System MUST produce remediation suggestions for affected functions.
- **FR-021**: System MUST write remediated source code into a separate `remediated_project` output.
- **FR-022**: System MUST preserve the original STM32 project files during remediation.
- **FR-023**: System MUST provide a GUI workflow for entering credentials, selecting a model, uploading guidelines, generating context, running analysis, and running remediation.
- **FR-024**: System MUST show clear progress and completion status for context generation, analysis, and remediation.
- **FR-025**: System MUST show actionable error messages when a required input is missing, invalid, or unusable.
- **FR-026**: System MUST keep Phase 1 outputs limited to project context, final analysis report, and remediated project copy.
- **FR-027**: System MUST exclude compilation, retry compilation, formal review, and PDF report generation from Phase 1 behavior.

### Key Entities

- **STM32 Project**: The user-selected embedded project to inspect; includes source files, project structure, symbols, interfaces, function relationships, and peripheral usage.
- **Source File**: A discovered application file that may contain functions, symbols, dependencies, and remediation targets.
- **Function**: A callable code unit analyzed for guideline compliance and potentially remediated.
- **Dependency Graph**: The discovered relationships among project files or components used to understand context.
- **Call Graph**: The discovered function-call relationships used to understand execution and dependency context.
- **Symbol Ownership**: The association between symbols and the source files or components responsible for defining or owning them.
- **Interface Contract**: A discovered boundary or expected interaction between project components.
- **Peripheral Ownership**: The association between STM32 peripherals and the project code responsible for using or managing them.
- **Coding Guideline Set**: The user-provided compliance rules used during analysis.
- **Analysis Issue**: A reported compliance finding containing affected location, violated guideline, explanation, and remediation relevance.
- **Analysis Report**: The consolidated output of compliance analysis, represented by `final_analysis_report.json`.
- **Remediation Task**: A unit of work derived from an analysis issue that targets an affected function for correction.
- **Remediated Project**: A separate output project containing suggested source code updates while preserving the original project.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: For a representative STM32 project with at least 20 application source files, users can generate project context in under 5 minutes.
- **SC-002**: Context generation identifies at least 95% of expected application source files in representative STM32 projects used for validation.
- **SC-003**: In validation projects with known call relationships, the generated call graph captures at least 90% of expected function-call relationships relevant to analyzed functions.
- **SC-004**: For a validation guideline set with seeded violations, analysis reports at least 85% of expected violations with the affected function and guideline identified.
- **SC-005**: At least 95% of analysis issues in the final report include an affected location, guideline reference, and human-readable explanation.
- **SC-006**: For analysis reports with remediable function-level issues, remediation creates a separate remediated project without modifying the original project in 100% of completed runs.
- **SC-007**: At least 90% of remediation tasks with a uniquely identifiable affected function produce either a remediated function or an explicit unresolved status.
- **SC-008**: A first-time user can complete the GUI workflow from credential entry through remediation output in under 15 minutes for a small validation project, excluding time spent waiting for external AI processing.
- **SC-009**: At least 90% of required-input errors during validation provide a message that identifies the missing or invalid input and the next corrective action.

## Assumptions

- Phase 1 users are embedded developers, compliance reviewers, or technical leads working with STM32 Embedded C projects.
- The selected project is available locally and the user has permission to read the source files and write output artifacts.
- Coding guidelines are provided in a structured file that can be loaded and mapped to individual guideline checks.
- The AI-assisted steps require a user-provided credential and selected model before analysis or remediation can run.
- Remediation is advisory and produces a separate project copy for human review rather than guaranteeing production-ready code.
- The system may continue partial analysis when non-critical files cannot be read, provided skipped content is clearly reported.
- Compilation, retry compilation, formal review, and PDF generation are intentionally deferred to a future phase.
