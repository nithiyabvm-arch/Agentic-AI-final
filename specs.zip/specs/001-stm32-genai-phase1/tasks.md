# Tasks: STM32 GenAI Analyzer Phase 1

**Input**: Design documents from `specs/001-stm32-genai-phase1/`

**Prerequisites**: [plan.md](./plan.md), [spec.md](./spec.md), [research.md](./research.md), [data-model.md](./data-model.md), [contracts/](./contracts/), [quickstart.md](./quickstart.md)

**Tests**: Included because the implementation plan defines contract, unit, integration, and GUI workflow validation for Phase 1.

**Organization**: Tasks are grouped by user story so each story can be implemented and tested independently after shared foundation work is complete.

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Initialize the Python package, dependency metadata, test layout, and baseline project files.

- [ ] T001 Create Python package and test directory skeleton in `stm32_genai_analyzer/` and `tests/`
- [ ] T002 Create package marker files in `stm32_genai_analyzer/__init__.py`, `stm32_genai_analyzer/models/__init__.py`, `stm32_genai_analyzer/context_builder/__init__.py`, `stm32_genai_analyzer/analysis/__init__.py`, `stm32_genai_analyzer/remediation/__init__.py`, `stm32_genai_analyzer/gui/__init__.py`, and `stm32_genai_analyzer/utils/__init__.py`
- [ ] T003 Configure project metadata and runtime dependencies in `pyproject.toml`
- [ ] T004 [P] Configure pytest defaults and test markers in `pytest.ini`
- [ ] T005 [P] Create development environment example in `.env.example`
- [ ] T006 [P] Create baseline README setup notes in `README.md`
- [ ] T007 [P] Create sample guideline fixture directory and placeholder metadata in `tests/fixtures/guidelines/README.md`
- [ ] T008 [P] Create sample STM32 fixture directory and placeholder metadata in `tests/fixtures/sample_stm32_project/README.md`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Implement shared models, file utilities, configuration, schema loading, logging, and fake AI boundaries required by all user stories.

**Critical**: No user story implementation should begin until this phase is complete.

- [ ] T009 Implement application configuration and default output names in `stm32_genai_analyzer/config.py`
- [ ] T010 [P] Implement path normalization and project-relative path helpers in `stm32_genai_analyzer/utils/paths.py`
- [ ] T011 [P] Implement JSON read/write and schema loading helpers in `stm32_genai_analyzer/utils/json_io.py`
- [ ] T012 [P] Implement structured logging helpers in `stm32_genai_analyzer/utils/logging.py`
- [ ] T013 [P] Implement context Pydantic models matching `contracts/context.schema.json` in `stm32_genai_analyzer/models/context.py`
- [ ] T014 [P] Implement guideline Pydantic models matching `contracts/guidelines.schema.json` in `stm32_genai_analyzer/models/guidelines.py`
- [ ] T015 [P] Implement analysis Pydantic models matching `contracts/final-analysis-report.schema.json` in `stm32_genai_analyzer/models/analysis.py`
- [ ] T016 [P] Implement remediation Pydantic models matching `contracts/remediation-manifest.schema.json` in `stm32_genai_analyzer/models/remediation.py`
- [ ] T017 Create shared validation exceptions and result types in `stm32_genai_analyzer/models/__init__.py`
- [ ] T018 [P] Create contract test for guideline schema fixtures in `tests/contract/test_guidelines_schema.py`
- [ ] T019 [P] Create contract test for context schema fixtures in `tests/contract/test_context_schema.py`
- [ ] T020 [P] Create contract test for analysis report schema fixtures in `tests/contract/test_analysis_report_schema.py`
- [ ] T021 [P] Create contract test for remediation manifest schema fixtures in `tests/contract/test_remediation_manifest_schema.py`
- [ ] T022 [P] Create reusable fake AI client fixture in `tests/fixtures/fake_ai_client.py`
- [ ] T023 [P] Create representative STM32 C and header fixture files in `tests/fixtures/sample_stm32_project/Core/Src/main.c` and `tests/fixtures/sample_stm32_project/Core/Inc/main.h`
- [ ] T024 [P] Create valid and invalid guideline JSON fixtures in `tests/fixtures/guidelines/valid_guidelines.json` and `tests/fixtures/guidelines/invalid_guidelines.json`

**Checkpoint**: Foundation ready. Contract schemas, models, utilities, and fixtures exist for all downstream stories.

---

## Phase 3: User Story 1 - Build Project Understanding (Priority: P1) MVP

**Goal**: Inspect an STM32 project and produce a complete `context.json` with discovered source files, dependencies, call graph, symbols, interfaces, peripherals, and diagnostics.

**Independent Test**: Run context generation on the sample STM32 project and verify the exported context identifies source files, dependency relationships, call relationships, symbol ownership, interface contracts, and peripheral ownership.

### Tests for User Story 1

- [ ] T025 [P] [US1] Create source discovery unit tests in `tests/unit/test_discovery.py`
- [ ] T026 [P] [US1] Create C parser function extraction unit tests in `tests/unit/test_c_parser.py`
- [ ] T027 [P] [US1] Create dependency and call graph unit tests in `tests/unit/test_graph_builders.py`
- [ ] T028 [P] [US1] Create symbol, interface, and peripheral inference unit tests in `tests/unit/test_context_inference.py`
- [ ] T029 [P] [US1] Create context export integration test in `tests/integration/test_context_generation.py`

### Implementation for User Story 1

- [ ] T030 [P] [US1] Implement STM32 source file discovery and build directory exclusions in `stm32_genai_analyzer/context_builder/discovery.py`
- [ ] T031 [P] [US1] Implement tree-sitter C parsing with safe fallback behavior in `stm32_genai_analyzer/context_builder/parser.py`
- [ ] T032 [US1] Implement include and file dependency graph builder in `stm32_genai_analyzer/context_builder/dependencies.py`
- [ ] T033 [US1] Implement function definition indexing and call graph builder in `stm32_genai_analyzer/context_builder/call_graph.py`
- [ ] T034 [US1] Implement symbol ownership inference in `stm32_genai_analyzer/context_builder/symbols.py`
- [ ] T035 [US1] Implement interface contract inference in `stm32_genai_analyzer/context_builder/interfaces.py`
- [ ] T036 [US1] Implement STM32 peripheral ownership inference in `stm32_genai_analyzer/context_builder/peripherals.py`
- [ ] T037 [US1] Implement context artifact exporter and schema validation in `stm32_genai_analyzer/context_builder/exporter.py`
- [ ] T038 [US1] Add context builder orchestration function in `stm32_genai_analyzer/context_builder/__init__.py`
- [ ] T039 [US1] Ensure skipped and unreadable files are reported in context diagnostics in `stm32_genai_analyzer/context_builder/exporter.py`

**Checkpoint**: User Story 1 is functional when `context.json` can be generated and validated from the sample project without requiring analysis, remediation, or GUI code.

---

## Phase 4: User Story 2 - Analyze Coding Guideline Compliance (Priority: P2)

**Goal**: Load structured guidelines and generated context, run AI-assisted function analysis, and produce `final_analysis_report.json`.

**Independent Test**: Use a known guideline set and sample project context with seeded violations, run analysis with a fake AI client, and verify the final report includes expected violations and affected functions.

### Tests for User Story 2

- [ ] T040 [P] [US2] Create guideline loader unit tests for valid and malformed files in `tests/unit/test_guideline_loader.py`
- [ ] T041 [P] [US2] Create analysis prompt builder unit tests in `tests/unit/test_prompt_builders.py`
- [ ] T042 [P] [US2] Create OpenAI adapter boundary tests with fake responses in `tests/unit/test_openai_client.py`
- [ ] T043 [P] [US2] Create analysis report generation unit tests in `tests/unit/test_analysis_reporter.py`
- [ ] T044 [P] [US2] Create context-to-analysis integration test with fake AI client in `tests/integration/test_context_to_analysis.py`

### Implementation for User Story 2

- [ ] T045 [P] [US2] Implement guideline loading and model validation in `stm32_genai_analyzer/analysis/guideline_loader.py`
- [ ] T046 [US2] Implement function analysis prompt construction from context and guidelines in `stm32_genai_analyzer/analysis/prompt_builder.py`
- [ ] T047 [US2] Implement OpenAI structured-output adapter with retries and timeout handling in `stm32_genai_analyzer/analysis/openai_client.py`
- [ ] T048 [US2] Implement per-function analysis orchestration and skipped item handling in `stm32_genai_analyzer/analysis/analyzer.py`
- [ ] T049 [US2] Implement issue merging, summary counts, and `final_analysis_report.json` writing in `stm32_genai_analyzer/analysis/reporter.py`
- [ ] T050 [US2] Add analysis node orchestration function in `stm32_genai_analyzer/analysis/__init__.py`
- [ ] T051 [US2] Block analysis with actionable errors for missing credentials, missing model, invalid context, or invalid guidelines in `stm32_genai_analyzer/analysis/analyzer.py`

**Checkpoint**: User Story 2 is functional when analysis can run from `context.json` and guideline JSON to a schema-valid `final_analysis_report.json` using a fake AI client.

---

## Phase 5: User Story 3 - Generate Remediated Project Copy (Priority: P3)

**Goal**: Read the analysis report, resolve affected functions, generate remediation suggestions, write changes only to `remediated_project`, and produce a remediation manifest.

**Independent Test**: Run remediation on a seeded analysis report and verify only affected functions are changed in a copied project while the original project remains unchanged.

### Tests for User Story 3

- [ ] T052 [P] [US3] Create analysis issue reader unit tests in `tests/unit/test_issue_reader.py`
- [ ] T053 [P] [US3] Create affected function extraction unit tests in `tests/unit/test_function_extractor.py`
- [ ] T054 [P] [US3] Create remediation prompt builder unit tests in `tests/unit/test_remediation_prompt_builder.py`
- [ ] T055 [P] [US3] Create project writer preservation unit tests in `tests/unit/test_project_writer.py`
- [ ] T056 [P] [US3] Create analysis-to-remediation integration test in `tests/integration/test_analysis_to_remediation.py`

### Implementation for User Story 3

- [ ] T057 [P] [US3] Implement final analysis report reader and remediation task selection in `stm32_genai_analyzer/remediation/issue_reader.py`
- [ ] T058 [US3] Implement unique affected function body extraction in `stm32_genai_analyzer/remediation/function_extractor.py`
- [ ] T059 [US3] Implement remediation prompt construction from issue and function context in `stm32_genai_analyzer/remediation/prompt_builder.py`
- [ ] T060 [US3] Implement AI-assisted remediation orchestration with fake-client compatibility in `stm32_genai_analyzer/remediation/remediator.py`
- [ ] T061 [US3] Implement copy-first remediated project writer and function replacement in `stm32_genai_analyzer/remediation/project_writer.py`
- [ ] T062 [US3] Implement remediation manifest creation and schema validation in `stm32_genai_analyzer/remediation/manifest.py`
- [ ] T063 [US3] Add remediation node orchestration function in `stm32_genai_analyzer/remediation/__init__.py`
- [ ] T064 [US3] Mark ambiguous, missing, or unsafe remediation targets unresolved without modifying files in `stm32_genai_analyzer/remediation/remediator.py`

**Checkpoint**: User Story 3 is functional when remediation creates `remediated_project`, preserves the original project, and emits a schema-valid remediation manifest.

---

## Phase 6: User Story 4 - Operate Workflow Through a GUI (Priority: P4)

**Goal**: Provide a Streamlit GUI for API key entry, model selection, guideline upload, context generation, analysis, remediation, progress status, and artifact paths.

**Independent Test**: Open the GUI, complete each workflow action in sequence with mocked services, and verify expected state transitions and artifact outputs.

### Tests for User Story 4

- [ ] T065 [P] [US4] Create GUI state transition unit tests in `tests/unit/test_gui_state.py`
- [ ] T066 [P] [US4] Create GUI component smoke tests in `tests/unit/test_gui_components.py`
- [ ] T067 [P] [US4] Create GUI workflow integration test with mocked services in `tests/integration/test_gui_workflow_state.py`

### Implementation for User Story 4

- [ ] T068 [P] [US4] Implement GUI session state and prerequisite gating in `stm32_genai_analyzer/gui/state.py`
- [ ] T069 [US4] Implement reusable Streamlit input, status, and artifact components in `stm32_genai_analyzer/gui/components.py`
- [ ] T070 [US4] Implement Streamlit workflow page layout and action handlers in `stm32_genai_analyzer/gui/pages.py`
- [ ] T071 [US4] Implement Streamlit application entrypoint in `stm32_genai_analyzer/app.py`
- [ ] T072 [US4] Ensure GUI keeps API key in session state only and never writes it to artifacts in `stm32_genai_analyzer/gui/state.py`
- [ ] T073 [US4] Surface actionable GUI errors for missing project, invalid guidelines, missing API key, invalid context, and remediation ambiguity in `stm32_genai_analyzer/gui/components.py`

**Checkpoint**: User Story 4 is functional when a user can complete the full GUI workflow and see artifact paths for `context.json`, `final_analysis_report.json`, `remediated_project`, and the remediation manifest.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Complete documentation, validation, performance checks, and scope guards across all stories.

- [ ] T074 [P] Update quickstart implementation notes and commands in `specs/001-stm32-genai-phase1/quickstart.md`
- [ ] T075 [P] Add end-to-end manual validation checklist in `README.md`
- [ ] T076 Add explicit scope guards that exclude compiler, retry compilation, review node, and PDF generation in `stm32_genai_analyzer/config.py`
- [ ] T077 Add performance timing logs for context generation, analysis, and remediation in `stm32_genai_analyzer/utils/logging.py`
- [ ] T078 Run and document contract test command results in `specs/001-stm32-genai-phase1/checklists/requirements.md`
- [ ] T079 Run and document unit test command results in `specs/001-stm32-genai-phase1/checklists/requirements.md`
- [ ] T080 Run and document integration test command results in `specs/001-stm32-genai-phase1/checklists/requirements.md`
- [ ] T081 Run GUI smoke validation and document result in `specs/001-stm32-genai-phase1/checklists/requirements.md`

---

## Dependencies & Execution Order

### Phase Dependencies

- **Phase 1 Setup**: No dependencies.
- **Phase 2 Foundational**: Depends on Phase 1 completion and blocks all user stories.
- **Phase 3 US1**: Depends on Phase 2 and provides the MVP.
- **Phase 4 US2**: Depends on Phase 2 and uses US1 output for full integration, but can be tested with fixture `context.json`.
- **Phase 5 US3**: Depends on Phase 2 and uses US2 output for full integration, but can be tested with fixture `final_analysis_report.json`.
- **Phase 6 US4**: Depends on Phase 2 and integrates US1, US2, and US3 services through mocked or real orchestration.
- **Phase 7 Polish**: Depends on the completed stories selected for delivery.

### User Story Dependencies

- **US1 Build Project Understanding**: Required for the MVP and for real end-to-end analysis.
- **US2 Analyze Coding Guideline Compliance**: Requires valid context for real runs; independently testable with fixture context.
- **US3 Generate Remediated Project Copy**: Requires valid analysis report for real runs; independently testable with fixture report.
- **US4 Operate Workflow Through a GUI**: Orchestrates the other stories; independently testable with mocked services.

### Within Each User Story

- Write tests before implementation tasks in that story.
- Implement models and loaders before services.
- Implement services before orchestration functions.
- Validate artifact contracts before declaring story completion.
- Stop at each checkpoint and run the story's independent test.

## Parallel Opportunities

- Setup tasks T004-T008 can run in parallel after T001-T003.
- Foundational model, utility, fixture, and contract test tasks T010-T016 and T018-T024 can run in parallel after T009.
- US1 test tasks T025-T029 can run in parallel before US1 implementation.
- US2 test tasks T040-T044 can run in parallel before US2 implementation.
- US3 test tasks T052-T056 can run in parallel before US3 implementation.
- US4 test tasks T065-T067 can run in parallel before US4 implementation.
- After Phase 2, US2 and US3 can begin against fixture artifacts while US1 finalizes, provided final integration is re-run after upstream stories complete.

## Parallel Example: User Story 1

```text
Task: "T025 [US1] Create source discovery unit tests in tests/unit/test_discovery.py"
Task: "T026 [US1] Create C parser function extraction unit tests in tests/unit/test_c_parser.py"
Task: "T027 [US1] Create dependency and call graph unit tests in tests/unit/test_graph_builders.py"
Task: "T028 [US1] Create symbol, interface, and peripheral inference unit tests in tests/unit/test_context_inference.py"
Task: "T029 [US1] Create context export integration test in tests/integration/test_context_generation.py"
```

## Parallel Example: User Story 2

```text
Task: "T040 [US2] Create guideline loader unit tests for valid and malformed files in tests/unit/test_guideline_loader.py"
Task: "T041 [US2] Create analysis prompt builder unit tests in tests/unit/test_prompt_builders.py"
Task: "T042 [US2] Create OpenAI adapter boundary tests with fake responses in tests/unit/test_openai_client.py"
Task: "T043 [US2] Create analysis report generation unit tests in tests/unit/test_analysis_reporter.py"
Task: "T044 [US2] Create context-to-analysis integration test with fake AI client in tests/integration/test_context_to_analysis.py"
```

## Parallel Example: User Story 3

```text
Task: "T052 [US3] Create analysis issue reader unit tests in tests/unit/test_issue_reader.py"
Task: "T053 [US3] Create affected function extraction unit tests in tests/unit/test_function_extractor.py"
Task: "T054 [US3] Create remediation prompt builder unit tests in tests/unit/test_remediation_prompt_builder.py"
Task: "T055 [US3] Create project writer preservation unit tests in tests/unit/test_project_writer.py"
Task: "T056 [US3] Create analysis-to-remediation integration test in tests/integration/test_analysis_to_remediation.py"
```

## Parallel Example: User Story 4

```text
Task: "T065 [US4] Create GUI state transition unit tests in tests/unit/test_gui_state.py"
Task: "T066 [US4] Create GUI component smoke tests in tests/unit/test_gui_components.py"
Task: "T067 [US4] Create GUI workflow integration test with mocked services in tests/integration/test_gui_workflow_state.py"
```

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1 setup.
2. Complete Phase 2 foundation.
3. Complete Phase 3 User Story 1.
4. Validate `context.json` generation with `pytest tests/integration/test_context_generation.py`.
5. Demo context generation before adding analysis and remediation.

### Incremental Delivery

1. Setup plus foundation creates a runnable Python package and validated contracts.
2. US1 adds context generation and `context.json`.
3. US2 adds guideline analysis and `final_analysis_report.json`.
4. US3 adds safe remediation and `remediated_project`.
5. US4 adds GUI operation across the complete workflow.

### Parallel Team Strategy

1. Complete setup and foundational tasks together.
2. Assign one developer to US1 context builder.
3. Assign one developer to US2 analysis using fixture context.
4. Assign one developer to US3 remediation using fixture analysis report.
5. Assign one developer to US4 GUI state and mocked workflow while service modules stabilize.

## Notes

- `[P]` means the task touches a different file or can proceed without dependency on another incomplete task.
- `[US1]`, `[US2]`, `[US3]`, and `[US4]` labels map directly to the prioritized user stories in `spec.md`.
- Keep original STM32 project files read-only from the perspective of remediation; write changes only under `remediated_project`.
- Use fake AI clients in normal automated tests; reserve live OpenAI calls for manual validation.
