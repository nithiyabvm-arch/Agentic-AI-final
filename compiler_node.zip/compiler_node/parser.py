import re


def parse_build_output(build_result):

    output = (
        build_result["stdout"]
        + "\n"
        + build_result["stderr"]
    )

    pattern = (
        r'(.+?):(\d+):(\d+):\s+'
        r'(error|warning):\s+(.*)'
    )

    matches = re.findall(
        pattern,
        output
    )

    errors = []
    warnings = []

    for match in matches:

        file_path = match[0]
        line = int(match[1])
        column = int(match[2])
        severity = match[3]
        message = match[4]

        issue = {
            "file": file_path,
            "line": line,
            "column": column,
            "message": message
        }

        if severity == "error":
            errors.append(issue)
        else:
            warnings.append(issue)

    return {
        "build_status":
            "SUCCESS"
            if build_result["return_code"] == 0
            else "FAILED",

        "return_code":
            build_result["return_code"],

        "error_count":
            len(errors),

        "warning_count":
            len(warnings),

        "errors":
            errors,

        "warnings":
            warnings
    }