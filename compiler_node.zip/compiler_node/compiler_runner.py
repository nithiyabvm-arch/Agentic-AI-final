import json
import os

from compiler_node.compiler_adapter import (
    compile_project
)

from compiler_node.parser import (
    parse_build_output
)


def run_compiler():

    build_result = compile_project()

    report = parse_build_output(
        build_result
    )

    os.makedirs(
        "compile_reports",
        exist_ok=True
    )

    report_path = os.path.join(
        "compile_reports",
        "compile_report.json"
    )

    with open(
        report_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            report,
            f,
            indent=4
        )

    return report