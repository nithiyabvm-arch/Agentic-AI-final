import subprocess

MAKE_PATH = r"C:\ST\STM32CubeIDE_2.1.1\STM32CubeIDE\plugins\com.st.stm32cube.ide.mcu.externaltools.make.win32_2.2.100.202601091506\tools\bin\make.exe"

DEBUG_PATH = r"workspace\remediated_project\Debug"


def compile_project():

    print("INSIDE COMPILE_PROJECT")

    result = subprocess.run(
        [
            MAKE_PATH,
            "-j1",
            "-C",
            DEBUG_PATH,
            "all"
        ],
        capture_output=True,
        text=True
    )

    print("\n================ STDOUT ================\n")
    print(result.stdout)

    print("\n================ STDERR ================\n")
    print(result.stderr)

    print("\n================ RETURN CODE ================\n")
    print(result.returncode)

    return {
        "stdout": result.stdout,
        "stderr": result.stderr,
        "return_code": result.returncode
    }