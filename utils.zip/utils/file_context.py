import os
import re


def build_file_context(
    current_file,
    project_context
):
    """
    Build contextual information for a source file.

    Returns:
    {
        dependencies,
        owned_functions,
        owned_peripherals,
        interface_contracts,
        called_functions,
        protected_regions,
        shared_variables
    }
    """

    filename = os.path.basename(
        current_file
    )

    # ----------------------------------
    # Dependencies
    # ----------------------------------

    dependencies = project_context[
        "dependency_graph"
    ].get(
        filename,
        []
    )

    # ----------------------------------
    # Functions owned by this file
    # ----------------------------------

    owned_functions = []

    for func, owner in project_context[
        "symbol_ownership"
    ]["functions"].items():

        if owner == filename:

            owned_functions.append(
                func
            )

    # ----------------------------------
    # Peripheral ownership
    # ----------------------------------

    owned_peripherals = []

    for peripheral, owner in project_context[
        "peripheral_ownership"
    ].items():

        if owner == filename:

            owned_peripherals.append(
                peripheral
            )

    # ----------------------------------
    # Interface contracts
    # ----------------------------------

    interface_contracts = {}

    for func in owned_functions:

        if func in project_context[
            "interface_contracts"
        ]:

            interface_contracts[
                func
            ] = project_context[
                "interface_contracts"
            ][func]

    # ----------------------------------
    # Call graph information
    # ----------------------------------

    called_functions = {}

    for func in owned_functions:

        if func in project_context[
            "call_graph"
        ]:

            called_functions[
                func
            ] = project_context[
                "call_graph"
            ][func]

    # ----------------------------------
    # Protected regions
    # ----------------------------------

    protected_regions = {

        "user_code_regions":

            project_context[
                "protected_regions"
            ][
                "user_code_regions"
            ].get(
                filename,
                []
            ),

        "generated_functions":

            project_context[
                "protected_regions"
            ][
                "generated_functions"
            ].get(
                filename,
                []
            )
    }

    # ----------------------------------
    # Shared state information
    # ----------------------------------

    shared_variables = {}

    for variable, info in project_context[
        "shared_state_map"
    ].items():

        if (

            isinstance(info, dict)

            and

            info.get(
                "defined_in"
            ) == filename

        ):

            shared_variables[
                variable
            ] = info

    # ----------------------------------
    # Final context
    # ----------------------------------

    return {

        "dependencies":
            dependencies,

        "owned_functions":
            owned_functions,

        "owned_peripherals":
            owned_peripherals,

        "interface_contracts":
            interface_contracts,

        "called_functions":
            called_functions,

        "protected_regions":
            protected_regions,

        "shared_variables":
            shared_variables
    }


def extract_function_bodies(
    content,
    known_functions
):
    """
    Extract complete function bodies using
    brace tracking.

    Parameters:
        content (str)
        known_functions (list)

    Returns:
    {
        "function_name": "body"
    }
    """

    function_bodies = {}

    lines = content.splitlines()

    current_function = None

    collecting = False

    brace_depth = 0

    body_lines = []

    for line in lines:

        stripped = line.strip()

        # ----------------------------------
        # Detect function start
        # ----------------------------------

        if not collecting:

            for func in known_functions:

                if re.search(

                    rf"\b{re.escape(func)}\s*\(",

                    stripped

                ):

                    current_function = func

                    collecting = True

                    body_lines = [line]

                    brace_depth = (

                        line.count("{")

                        -

                        line.count("}")

                    )

                    break

            continue

        # ----------------------------------
        # Collect function body
        # ----------------------------------

        body_lines.append(line)

        brace_depth += line.count("{")

        brace_depth -= line.count("}")

        # ----------------------------------
        # Function completed
        # ----------------------------------

        if (

            collecting

            and

            brace_depth == 0

            and

            "{"
            in
            "\n".join(body_lines)

        ):

            function_bodies[
                current_function
            ] = "\n".join(
                body_lines
            )

            current_function = None

            collecting = False

            body_lines = []

    return function_bodies