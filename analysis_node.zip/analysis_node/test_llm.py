from llm_client import analyze_function


prompt = """
Analyze this STM32 function.

Coding Rule:
Do not use goto statements.

Code:

void Test()
{
    goto error;

error:
    return;
}

Return JSON only.
"""


result = analyze_function(
    model="gpt-4.1",
    temperature=0.2,
    prompt=prompt
)

print(result)