import os
import json

from analysis_node.prompt_builder import (
    build_analysis_prompt
)

from analysis_node.llm_client import (
    analyze_function
)

from utils.file_loader import (
    discover_application_files,
    load_file_content
)

from utils.file_context import (
    build_file_context,
    extract_function_bodies
)


def run_analysis(
    api_key,
    model,
    temperature,
    project_root,
    project_context,
    coding_guidelines
):
    """
    Run LLM analysis on STM32 application functions.
    """

    all_issues = []

    files = discover_application_files(
        project_root
    )

    total_files = len(
        files
    )

    total_functions = 0

    report_directory = (
        "analysis_reports"
    )

    os.makedirs(
        report_directory,
        exist_ok=True
    )

    print(
        f"\nDiscovered {total_files} application files.\n",
        flush=True
    )

    for file_path in files:

        filename = os.path.basename(
            file_path
        )

        file_issues = []

        print(
            f"\nAnalyzing File: {filename}",
            flush=True
        )

        try:

            content = load_file_content(
                file_path
            )

            file_context = build_file_context(
                file_path,
                project_context
            )

            known_functions = file_context.get(
                "owned_functions",
                []
            )

            total_functions += len(
                known_functions
            )

            if len(
                known_functions
            ) == 0:

                print(
                    "   No functions found.",
                    flush=True
                )

                continue

            function_bodies = (
                extract_function_bodies(
                    content,
                    known_functions
                )
            )

            if len(
                function_bodies
            ) == 0:

                print(
                    "   No function bodies extracted.",
                    flush=True
                )

                continue

            for (
                function_name,
                function_body
            ) in function_bodies.items():

                print(
                    f"   -> {function_name}",
                    flush=True
                )

                try:

                    prompt = (
                        build_analysis_prompt(
                            function_name,
                            function_body,
                            coding_guidelines
                        )
                    )

                    response = (
                        analyze_function(
                            api_key=api_key,
                            model=model,
                            temperature=temperature,
                            prompt=prompt
                        )
                    )

                    issues = response.get(
                        "issues",
                        []
                    )

                    for issue in issues:

                        simplified_issue = {

                            "file":
                                os.path.relpath(
                                    file_path,
                                    project_root
                                ),

                            "function":
                                issue.get(
                                    "function",
                                    function_name
                                ),

                            "rule_id":
                                issue.get(
                                    "rule_id",
                                    "UNKNOWN"
                                ),

                            "description":
                                issue.get(
                                    "description",
                                    ""
                                ),

                            "suggested_fix":
                                issue.get(
                                    "suggested_fix",
                                    ""
                                )
                        }

                        all_issues.append(
                            simplified_issue
                        )

                        file_issues.append(
                            simplified_issue
                        )

                    print(
                        f"      Issues Found: "
                        f"{len(issues)}",
                        flush=True
                    )

                except Exception as e:

                    print(
                        f"      Error analyzing "
                        f"{function_name}: {e}",
                        flush=True
                    )

            file_report = {

                "summary": {

                    "file":
                        os.path.relpath(
                            file_path,
                            project_root
                        ),

                    "total_functions":
                        len(
                            known_functions
                        ),

                    "total_issues":
                        len(
                            file_issues
                        )
                },

                "issues":
                    file_issues
            }

            report_name = (
                os.path.splitext(
                    filename
                )[0]
            )

            report_path = (
                os.path.join(
                    report_directory,
                    f"{report_name}_analysis.json"
                )
            )

            with open(
                report_path,
                "w",
                encoding="utf-8"
            ) as f:

                json.dump(
                    file_report,
                    f,
                    indent=4
                )

            print(
                f"   Saved: {report_path}",
                flush=True
            )

        except Exception as e:

            print(
                f"Error analyzing "
                f"{filename}: {e}",
                flush=True
            )

    analysis_report = {

        "summary": {

            "total_files":
                total_files,

            "total_functions":
                total_functions,

            "total_issues":
                len(
                    all_issues
                )
        },

        "issues":
            all_issues
    }

    final_report_path = (
        os.path.join(
            report_directory,
            "final_analysis_report.json"
        )
    )

    with open(
        final_report_path,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            analysis_report,
            f,
            indent=4
        )

    print(
        "\nAnalysis Report Generated Successfully",
        flush=True
    )

    print(
        f"Output File: "
        f"{final_report_path}",
        flush=True
    )

    print(
        f"Total Files: "
        f"{total_files}",
        flush=True
    )

    print(
        f"Total Functions: "
        f"{total_functions}",
        flush=True
    )

    print(
        f"Total Issues: "
        f"{len(all_issues)}",
        flush=True
    )

    return analysis_report
