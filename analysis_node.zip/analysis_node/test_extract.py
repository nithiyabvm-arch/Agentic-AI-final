from utils.file_loader import load_file_content
from utils.file_context import extract_function_bodies

content = load_file_content(
    r"C:\Users\acer\Downloads\Nithiya_poc\HVAC\Core\Src\motor_controller.c"
)
bodies = extract_function_bodies(
    content,
    [
        "MotorController_Update",
        "MotorController_MoveTo"
    ]
)

print(
    bodies["MotorController_Update"]
)