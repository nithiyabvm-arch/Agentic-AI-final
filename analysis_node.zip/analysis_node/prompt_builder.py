import json


def build_analysis_prompt(
    function_name,
    function_body,
    guidelines
):

    guideline_text = ""

    for rule in guidelines:

        guideline_text += (
            f"Rule ID: {rule['rule_id']}\n"
            f"Description: {rule['description']}\n"
            f"Suggested Fix: {rule['suggested_fix']}\n\n"
        )

    prompt = f"""
You are an expert STM32 Embedded C static analysis assistant.

Analyze the function against the provided coding guidelines.

Function Name:
{function_name}

Function Source Code:

{function_body}

Coding Guidelines:

{guideline_text}

Tasks:

1. Identify ONLY actual coding guideline violations.
2. Specify the violated rule ID.
3. Explain why it is a violation.
4. Provide a suggested fix.
5. Ignore coding styles that already comply.
6. Do NOT report informational observations.
7. Do NOT invent violations.
8. Do NOT report "No change needed".
9. Return an empty issues list if no violations exist.

Return ONLY valid JSON.

Expected JSON format:

{{
    "issues": [
        {{
            "function": "{function_name}",
            "rule_id": "C001",
            "description": "Magic number detected.",
            "suggested_fix": "Replace magic number with a named constant."
        }}
    ]
}}

If no violations exist:

{{
    "issues": []
}}
"""

    return prompt
