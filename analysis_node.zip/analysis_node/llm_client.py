import json

from openai import OpenAI


def clean_llm_code_output(code):

    code = code.strip()

    if code.startswith("```json"):
        code = code[7:]

    if code.startswith("```"):
        code = code[3:]

    if code.endswith("```"):
        code = code[:-3]

    code = code.strip()

    code = code.replace(
        "\\n",
        "\n"
    )

    code = code.replace(
        "\\t",
        "    "
    )

    code = code.replace(
        "\\r",
        ""
    )

    code = code.replace(
        "`",
        ""
    )

    return code.strip()


def analyze_function(
    api_key,
    model,
    temperature,
    prompt
):
    """
    Send prompt to GPT and return JSON output.
    """

    try:

        client = OpenAI(
            api_key=api_key
        )

        response = client.responses.create(
            model=model,
            input=prompt,
            temperature=temperature
        )

        output = response.output_text

        output = clean_llm_code_output(
            output
        )

        return json.loads(
            output
        )
    
    except Exception as e:

     return {
        "issues": [
            {
                "function": "UNKNOWN",
                "rule_id": "LLM_ERROR",
                "description": str(e),
                "suggested_fix":
                    "Verify API key, model name and prompt."
            }
        ]
    }