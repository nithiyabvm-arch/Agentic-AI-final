from prompt_builder import build_analysis_prompt


guidelines = [
    {
        "rule_id": "C001",
        "description": "Do not use goto statements for control flow",
        "severity": "HIGH",
        "suggested_fix": (
            "Replace goto statements with structured "
            "control flow constructs."
        )
    },
    {
        "rule_id": "C006",
        "description": (
            "All variables shall be initialized "
            "before first use"
        ),
        "severity": "HIGH",
        "suggested_fix": (
            "Initialize variables at declaration."
        )
    }
]


function_body = """
void TestFunction(void)
{
    int x;

    goto ERROR;

ERROR:
    x++;

    return;
}
"""


prompt = build_analysis_prompt(
    function_name="TestFunction",
    function_body=function_body,
    guidelines=guidelines
)


print(prompt)