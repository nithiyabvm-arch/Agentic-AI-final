import os
import json

from analysis_node.runner import (
    run_analysis
)


API_KEY = input(
    "Enter OpenAI API Key: "
).strip()

MODEL = "gpt-4.1"
TEMPERATURE = 0.2

PROJECT_ROOT = (
    r"C:\Users\acer\Downloads\Nithiya_poc\HVAC"
)


with open(
    "context.json",
    "r",
    encoding="utf-8"
) as f:

    project_context = json.load(
        f
    )


with open(
    "custom_guidelines.json",
    "r",
    encoding="utf-8"
) as f:

    coding_guidelines = json.load(
        f
    )


report = run_analysis(
    api_key=API_KEY,
    model=MODEL,
    temperature=TEMPERATURE,
    project_root=PROJECT_ROOT,
    project_context=project_context,
    coding_guidelines=coding_guidelines
)


print(
    "\n========== FINAL REPORT ==========\n"
)

print(
    json.dumps(
        report,
        indent=4
    )
)