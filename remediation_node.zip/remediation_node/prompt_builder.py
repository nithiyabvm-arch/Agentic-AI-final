def build_remediation_prompt(
    issue,
    function_code
):
    """
    Build remediation prompt for STM32 C code.
    """

    prompt = f"""
You are an expert STM32 Embedded C remediation assistant.

Your task is to fix ONE coding guideline violation.

==================================================
VIOLATION DETAILS
==================================================

Function:
{issue.get("function", "")}

Rule ID:
{issue.get("rule_id", "")}

Description:
{issue.get("description", "")}

Suggested Fix:
{issue.get("suggested_fix", "")}

==================================================
FUNCTION SOURCE CODE
==================================================

{function_code}

==================================================
STRICT RULES
==================================================

1. Fix ONLY the reported violation.
2. Make the SMALLEST possible code change.
3. Do NOT rewrite the entire function.
4. Do NOT change function signature.
5. Do NOT change return type.
6. Do NOT change parameter types.
7. Do NOT rename variables.
8. Do NOT add new APIs.
9. Do NOT add new functions.
10. Do NOT add includes.
11. Do NOT add typedefs.
12. Do NOT add enums.
13. Do NOT add structs.
14. Do NOT add global variables.
15. Preserve all existing logic.
16. Preserve all comments.
17. Preserve all formatting as much as possible.
18. Do NOT modify unrelated lines.
19. Return ONLY valid C code.
20. Return ONLY the corrected function.
21. Do NOT use markdown.
22. Do NOT return ```c.

EXAMPLE

Violation:
Magic number 10 detected.

Suggested Fix:
Replace magic number with named constant.

GOOD FIX:

const uint32_t delay_ms = 10U;
HAL_Delay(delay_ms);

BAD FIX:

- Rewriting entire function
- Changing function signature
- Adding unrelated variables
- Refactoring code

Return ONLY the corrected function.
"""

    return prompt
