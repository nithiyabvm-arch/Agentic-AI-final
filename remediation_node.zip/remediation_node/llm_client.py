from openai import OpenAI


def clean_llm_code_output(code):

    code = code.strip()

    if code.startswith("```c"):
        code = code[4:]

    if code.startswith("```"):
        code = code[3:]

    if code.endswith("```"):
        code = code[:-3]

    code = code.strip()

    code = code.replace("\\n", "\n")
    code = code.replace("\\t", "    ")
    code = code.replace("\\r", "")

    code = code.replace("`", "")

    return code.strip()


def remediate_function(
    api_key,
    model,
    temperature,
    prompt
):
    """
    Call GPT for remediation.
    """

    try:

        client = OpenAI(
            api_key=api_key
        )

        response = client.responses.create(
            model=model,
            input=prompt,
            temperature=temperature
        )

        result = response.output_text

        print("\n========== RAW GPT OUTPUT ==========\n")
        print(result[:1500])
        print("\n===================================\n")

        result = clean_llm_code_output(
            result
        )

        forbidden_tokens = [

            "#include",

            "#define",

            "typedef",

            "enum ",

            "struct ",

            "#ifndef",

            "#endif",

            "#pragma"
        ]

        for token in forbidden_tokens:

            if token in result:

                raise Exception(
                    f"Invalid remediation output. "
                    f"Contains forbidden token: {token}"
                )

        return result

    except Exception as e:

        print(
            f"Remediation LLM Error: {e}"
        )

        raise