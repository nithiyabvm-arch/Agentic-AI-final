from remediation_node.remediation_node_runner import (
    run_remediation
)

API_KEY = input(
    "Enter OpenAI API Key: "
)

run_remediation(

    api_key=API_KEY,

    model="gpt-4.1",

    temperature=0.2,

    workspace_root="workspace",

    analysis_report_path=
    "analysis_reports/final_analysis_report.json"
)