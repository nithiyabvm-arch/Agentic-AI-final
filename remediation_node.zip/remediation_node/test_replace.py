from remediation_node.code_replacer import (
    replace_function_body
)

old_code = """
void TestFunction(void)
{
    int x;
    x++;
}
"""

new_code = """
void TestFunction(void)
{
    int x = 0;
    x++;
}
"""

file_content = f"""
Header

{old_code}

Footer
"""

updated = replace_function_body(
    file_content,
    old_code,
    new_code
)

print(updated)