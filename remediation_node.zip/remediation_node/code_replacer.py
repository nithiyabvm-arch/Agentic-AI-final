import re


def clean_llm_code_output(code):

    if not code:
        return code

    # Remove markdown fences
    code = re.sub(
        r"```[a-zA-Z]*",
        "",
        code
    )

    code = code.replace(
        "```",
        ""
    )

    code = code.replace(
        "`",
        ""
    )

    # Remove escaped chars
    code = code.replace(
        "\\n",
        "\n"
    )

    code = code.replace(
        "\\t",
        "    "
    )

    code = code.replace(
        "\\r",
        ""
    )

    # Remove includes
    code = re.sub(
        r'#include\s+[<"].*[>"]\s*\n?',
        '',
        code
    )

    # Remove defines
    code = re.sub(
        r'#define.*\n?',
        '',
        code
    )

    # Remove pragma
    code = re.sub(
        r'#pragma.*\n?',
        '',
        code
    )

    return code.strip()


def replace_function_body(
    source_content,
    old_function,
    new_function
):
    """
    Replace old function with remediated function.
    """

    new_function = clean_llm_code_output(
        new_function
    )

    print("\n========== CLEANED FUNCTION ==========\n")
    print(new_function[:1000])
    print("\n=====================================\n")

    return source_content.replace(
        old_function,
        new_function
    )