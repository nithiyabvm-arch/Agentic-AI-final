import os
import json

from utils.file_loader import (
    load_file_content
)

from utils.file_context import (
    extract_function_bodies
)

from remediation_node.prompt_builder import (
    build_remediation_prompt
)

from remediation_node.llm_client import (
    remediate_function
)

from remediation_node.code_replacer import (
    replace_function_body
)


def run_remediation(
    api_key,
    model,
    temperature,
    workspace_root,
    analysis_report_path
):
    """
    Perform remediation on remediated_project.
    """

    project_root = os.path.dirname(
    workspace_root
)

    remediated_root = os.path.join(
        project_root,
        "workspace",
        "remediated_project"
    )

    print("=" * 80)
    print("PROJECT ROOT :", project_root)
    print("REMEDIATED ROOT :", remediated_root)
    print("=" * 80)

    with open(
        analysis_report_path,
        "r",
        encoding="utf-8"
    ) as f:

        report = json.load(f)

    issues = report["issues"]

    print(
        f"\nIssues To Remediate : {len(issues)}\n"
    )

    # --------------------------------------------------
    # Metrics
    # --------------------------------------------------

    files_processed = set()

    functions_updated = 0

    issues_fixed = 0

    functions_failed = 0

    # --------------------------------------------------
    # Process each issue
    # --------------------------------------------------

    for issue in issues:

        try:

            relative_file = issue[
                "file"
            ]

            function_name = issue[
                "function"
            ]

            target_file = os.path.join(
                remediated_root,
                relative_file
            )

            print(
                f"\nProcessing : {function_name}"
            )
            
            print(f"Opening File : {target_file}")

            print(
                "Exists :",
                os.path.exists(target_file)
            )

            content = load_file_content(
                target_file
            )

            functions = (
                extract_function_bodies(
                    content,
                    [function_name]
                )
            )

            if (
                function_name
                not in functions
            ):

                print(
                    f"Function not found : "
                    f"{function_name}"
                )

                functions_failed += 1

                continue

            old_function = functions[
                function_name
            ]

            print("\n" + "=" * 80)
            print("FUNCTION SENT TO GPT")
            print("=" * 80)

            print(old_function)

            print("=" * 80)

            prompt = (
                build_remediation_prompt(
                    issue,
                    old_function
                )
            )

            new_function = (
                remediate_function(
                    api_key=api_key,
                    model=model,
                    temperature=temperature,
                    prompt=prompt
                )
            )

            print("\n" + "=" * 80)
            print("GPT RETURNED")
            print("=" * 80)

            print(new_function)

            print("=" * 80)

            updated_content = (
                replace_function_body(
                    content,
                    old_function,
                    new_function
                )
            )

            with open(
                target_file,
                "w",
                encoding="utf-8"
            ) as f:

                f.write(
                    updated_content
                )

            print(
                f"Remediated : "
                f"{function_name}"
            )

            files_processed.add(
                relative_file
            )

            functions_updated += 1

            issues_fixed += 1

        except Exception as e:

            functions_failed += 1

            print("\n" + "=" * 80)

            print(f"FAILED FUNCTION : {function_name}")

            print(f"TARGET FILE : {target_file}")

            print(f"EXCEPTION TYPE : {type(e).__name__}")

            print(f"REASON : {repr(e)}")

            print("=" * 80)

    # --------------------------------------------------
    # Summary
    # --------------------------------------------------

    print("\n" + "=" * 60)
    print("REMEDIATION SUMMARY")
    print("=" * 60)

    print(
        f"Files Processed : "
        f"{len(files_processed)}"
    )

    print(
        f"Functions Updated : "
        f"{functions_updated}"
    )

    print(
        f"Issues Fixed : "
        f"{issues_fixed}"
    )

    print(
        f"Functions Failed : "
        f"{functions_failed}"
    )

    print("=" * 60)

    # --------------------------------------------------
    # Save Remediation Report
    # --------------------------------------------------

    os.makedirs(
        "remediation_reports",
        exist_ok=True
    )

    remediation_report = {

        "files_processed":
            len(files_processed),

        "functions_updated":
            functions_updated,

        "issues_fixed":
            issues_fixed,

        "functions_failed":
            functions_failed
    }

    with open(
        "remediation_reports/remediation_report.json",
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            remediation_report,
            f,
            indent=4
        )

    print(
        "\nRemediation Report Saved"
    )

    print(
        "Output File : remediation_reports/remediation_report.json"
    )

    print(
        "\nRemediation Completed"
    )

    return remediation_report