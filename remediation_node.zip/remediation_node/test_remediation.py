from remediation_node.prompt_builder import (
    build_remediation_prompt
)

from remediation_node.llm_client import (
    remediate_function
)

issue = {

    "issue_id":"ISSUE_0001",

    "rule_id":"C006",

    "description":
    "Variable not initialized",

    "recommendation":
    "Initialize variable"
}

function_body = """
void TestFunction(void)
{
    int x;
    x++;
}
"""

prompt = build_remediation_prompt(

    issue,

    function_body
)

result = remediate_function(

    model="gpt-4.1",

    temperature=0.2,

    prompt=prompt
)

print(result)